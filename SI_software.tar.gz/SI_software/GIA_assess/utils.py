"""
Functions:
    get_function:           Calculate conversion factor per degree for converting
                            dimensionless SH coefficients to/from EWH, Geoid, elastic
                            vertical, elastic horizontal or viscoelastic coefficients.
    construct_DHgrid:       Determine the latitudes and longitudes of a Driscoll
                            and Healy grid. Grid spacing (dtheta) is determined by lmax.
    get_mapping:            Get mapping from one set of lat/lon coordinate pairs
                            to another using kd-tree for nearest neighbour.
    lonlat_to_cartesian:    Calculates x,y,z coordinates of a lat/lon point on a
                            sphere with radius R.
    serial_date_to_YMD:     Convert serial date to year, month, day.
    YMD_to_decimal_year:    Convert year, month, day to decimal year.

Classes:
    linear_regression:      Perform linear regression on x,y data.

TO DO:
- check that the conversion functions are correct

Author: Rebecca McGirr, 2025
Research School of Earth Sciences
The Australian National University
"""

import numpy as np
import datetime as dt
from scipy.spatial import cKDTree
from .constants import rad_e, rho_e, rho_w

def get_function(filename, lmax=180, type=None, frame=None):
    '''
    Calculate conversion factor per degree for converting
    dimensionless SH coefficients to/from EWH, Geoid, elastic
    vertical, elastic horizontal or viscoelastic coefficients.

    Args:
    filename (str): love number file (fromat: degree, height, lateral, potential)
    lmax (int):     maximum degree of SH coefficients
    type (str):     type of function to convert to/from dimensionless SH coefficients
                    (Geoid, EWH, elastic_vertical, elastic_horizontal, viscoelastic)
    frame (str):    frame of reference for love numbers (figure, mass, None)

    Returns:
    Fn (array): conversion factor per degree
    '''

    if type == None:
        print("Please specify the type of conversion function as one of: ")
        print("'Geoid', 'EWH', 'elastic_vertical', 'elastic_horizontal', 'viscoelastic'")
        return

    # read in love numbers
    n, h, l, k = np.loadtxt(filename, unpack=True)[:,:lmax+1]
    k[0] = 0.0
    # if centre of figure use Blewitt et al. 2003 degree 1
    if frame == 'figure':
        h[1], l[1], k[1] = -0.269, 0.134, 0.021
    # if centre of mass, set degree 1 to zero
    elif frame == 'mass':
        h[1], l[1], k[1] = 0, 0, 0
    # if not specified, use values read from file
    elif frame == None:
        pass
    else:
        print("Unknown frame of reference, must be 'figure','mass' or None")

    # calculate conversion factor
    if type == 'Geoid':
        print(f"Getting function type {type}, using Earth radius {rad_e} m")
        Fn = rad_e # Wahr et al. 1998
    elif type == 'EWH':
        print(f"Getting function type {type}, using Earth radius {rad_e} m and density {rho_e} kg/m^3")
        Fn = (rad_e * rho_e) / (3 * rho_w) * (2 * n + 1) / (1 + k) # Wahr et al. 1998
    elif type == 'elastic_vertical':
        print(f"Getting function type {type}, using Earth radius {rad_e} m")
        Fn = (rad_e * h) / (1 + k) # Davis et al. 2004
    elif type == 'elastic_horizontal':
        print(f"Getting function type {type}, using Earth radius {rad_e} m")
        Fn = (rad_e * l) / (1 + k) # Farrell 1972
    elif type == 'viscoelastic':
        print(f"Getting function type {type}, using Earth radius {rad_e} m")
        # linear approximation (Purcell et al. 2012)
        # Fn = rad_e * (1.1677 * n - 0.5233) # 
        # tabulated values (Purcell et al. 2012)
        Fn = np.zeros(lmax+1)
        Fn[2:lmax+1] = rad_e * np.loadtxt('files/Ratios_Purcell2011.txt',usecols=1)[:lmax-1]
    else:
        print("Unknown type of conversion function, must be one of: ")
        print("'Geoid', 'EWH', 'elastic_vertical', 'elastic_horizontal', 'viscoelastic'")
        return
    return Fn 

def construct_DHgrid(lmax):
    '''
    Determine the latitudes and longitudes of a Driscoll
    and Healy grid. Grid spacing (dtheta) is determined by lmax.
    Latitude range is 90 to -90+dtheta
    Longitude range is 0 to 360-dtheta

    Args:
    lmax (int): maximum degree of SH coefficients

    Returns:
    lat (array): latitude coordinates of grid
    lon (array): longitude coordinates of grid
    '''
    # construct the mapping from the mascon grid to the DH grid
    N = 2 * lmax + 2
    dtheta = 180. / N
    # create new lats/lons
    lat = np.r_[90:-90:-1 * dtheta]
    lon = np.r_[0:360:dtheta]
    return lat, lon

def get_mapping(rlon, rlat, tlon, tlat):
    '''
    Get mapping from one set of lat/lon coordinate pairs 
    to another using kd-tree for nearest neighbour.

    Args:
    rlon (array): reference longitude coordinates
    rlat (array): reference latitude coordinates
    tlon (array): target longitude coordinates
    tlat (array): target latitude coordinates

    Returns:
    idx_near (array): index of nearest neighbour in target
    '''       
    # get cartesian coords for both grids
    xR, yR, zR = lonlat_to_cartesian(rlon.flatten(), rlat.flatten(), R=rad_e)
    xT, yT, zT = lonlat_to_cartesian(tlon.flatten(), tlat.flatten(), R=rad_e)

    # map from reference coords to target coords
    tree = cKDTree(list(zip(xR, yR, zR)))
    d, inds = tree.query(list(zip(xT, yT, zT)), k=1)
    idx_near = np.int_(inds.reshape(tlon.shape))

    return idx_near

def lonlat_to_cartesian(lon, lat, R=1):
    """
    Calculates x,y,z coordinates of a lat/lon point on a 
    sphere with radius R

    Args:
    lon (array): longitude in degrees
    lat (array): latitude in degrees
    R (float):   radius of sphere

    Returns:
    x (array): x-coordinate
    y (array): y-coordinate
    z (array): z-coordinate
    """
    lon_r = np.radians(lon)
    lat_r = np.radians(lat)

    x = R * np.cos(lat_r) * np.cos(lon_r)
    y = R * np.cos(lat_r) * np.sin(lon_r)
    z = R * np.sin(lat_r)
    return x, y, z

def serial_date_to_YMD(ref_date, time):
    '''
    Convert serial date to year, month, day

    Args: 
    ref_date (datetime): reference date
    time (array/int):    time in days since ref_date

    Returns:
    year (array/int):  year
    month (array/int): month
    day (array/int):   day
    '''
    # convert array of days since to year, month, day
    if isinstance(time, np.ndarray):
        year = np.zeros(len(time), dtype=int)
        month = np.zeros(len(time), dtype=int)
        day = np.zeros(len(time), dtype=int)
        for i in range(len(time)):
            new_date = ref_date + dt.timedelta(float(time[i]))
            year[i] = new_date.year
            month[i] = new_date.month
            day[i] = new_date.day

    # convert single day since to year, month, day
    elif isinstance(time, int):
        new_date = ref_date + dt.timedelta(time)
        year = new_date.year
        month = new_date.month
        day = new_date.day
    return year, month, day

def YMD_to_decimal_year(year, month, day):
    '''
    Convert year, month, day to decimal year

    Args:
    year (array/int):  year
    month (array/int): month
    day (array/int):   day

    Returns:
    decyear (array/float): decimal year
    '''
    # convert array of year, month, day to decimal year
    if isinstance(year, np.ndarray):
        decyear = np.zeros(len(year))
        for i in range(len(year)):
            days_in_year = dt.datetime(year[i], 12, 31).timetuple().tm_yday
            year_frac = (dt.datetime(year[i], month[i], day[i]).timetuple().tm_yday - 1) / days_in_year
            decyear[i] = year[i] + year_frac

    # convert single year, month, day to decimal year
    elif isinstance(year, int):
        days_in_year = dt.datetime(year, 12, 31).timetuple().tm_yday
        year_frac = (dt.datetime(year, month, day).timetuple().tm_yday - 1) / days_in_year
        decyear = year + year_frac

    return decyear

class linear_regression():
    def __init__(self, x, y, degree=1, weights=None, scale_sigma=False, 
                 annual=False, semiannual=False, verbose=True):
        self._fit_least_squares(x, y, degree, weights, scale_sigma, annual, semiannual, verbose)
    
    def _fit_least_squares(self, x, y, degree, weights, scale_sigma, annual, semiannual, verbose):
        '''
        Perform linear regression on data.

        x (array):          independent variable
        y (array):          dependent variable
        degree (int):       degree of polynomial to fit
        weights (array):    weights for weighted least squares
        scale_sigma (bool): scale the sigmas by the sum of square residuals
        annual (bool):      estimate annual cosine and sine amplitudes
        semiannual (bool):  estimate semiannual cosine and sine amplitudes
        verbose (bool):     print details of the model being fitted
        '''
        self.param_names = []
        if degree == 1:
            model = 'y = mx + b'
            self.param_names.extend(['m','b'])
            A = np.vstack([x, np.ones(len(x))])
            self.nparams = 2
        elif degree == 2:
            model = 'y = ax^2 + bx + c'
            self.param_names.extend(['a','b','c'])
            A = np.vstack([x**2, x, np.ones(len(x))])
            self.nparams = 3
        else:
            raise ValueError('Degree must be 1 or 2')
        if annual:
            model += ' + A*sin(2*pi*x) + B*cos(2*pi*x)'
            self.param_names.extend(['Asin','Acos'])
            A = np.vstack([A, np.sin(2*np.pi*x), np.cos(2*np.pi*x)])
            self.nparams += 2
        if semiannual:
            model += ' + C*sin(4*pi*x) + D*cos(4*pi*x)'
            self.param_names.extend(['SAsin','SAcos'])
            A = np.vstack([A, np.sin(4*np.pi*x), np.cos(4*np.pi*x)])
            self.nparams += 2
        A = A.T
        self.dof = len(y) - self.nparams

        if verbose: print('Fitting model:', model)
        if weights is None:
            VCV = np.linalg.inv(A.T @ A)
            self.params = VCV @ (A.T @ y)
            self.y_fit = A @ self.params
            self.res = y - self.y_fit
            # Compute the sum of squares
            self.ssr = np.sum(self.res**2)
        else:
            W = np.diag(weights)
            VCV = np.linalg.inv(A.T @ W @ A)
            self.params = VCV @ (A.T @ W @ y)
            self.y_fit = A @ self.params
            self.res = y - self.y_fit
            # Compute the weighted sum of squares
            wy = np.sqrt(weights) * y
            wA = np.sqrt(weights)[:, None] * A
            self.wssr = np.sum((wy - np.dot(wA, self.params))**2, axis=0)

        if scale_sigma:
            # Compute the scale factor   
            if weights is None: 
                self.scale = self.ssr / self.dof
            else:
                self.scale = self.wssr / self.dof
            # Compute the covariance matrix
            self.sigmas = np.sqrt(np.diag(VCV * self.scale)) 
        else:
            self.sigmas = np.sqrt(np.diag(VCV))

        # set param attributes
        for i in range(self.nparams):
            setattr(self, self.param_names[i], self.params[i])
            setattr(self, self.param_names[i] + '_sigma', self.sigmas[i])
