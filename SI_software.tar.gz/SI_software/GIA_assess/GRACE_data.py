"""
Classes:
    GRACE_data: Class to load and manipulate GRACE data

Author: Rebecca McGirr, 2025
Research School of Earth Sciences
The Australian National University
"""
import os
import numpy as np
import netCDF4 as nc
import datetime as dt
import pyshtools as pysh
from .utils import construct_DHgrid, get_mapping, serial_date_to_YMD, YMD_to_decimal_year

class GRACE_data:
    def __init__(self, filename: str):
        if os.path.isfile(filename):
            self.load_mascon_grid(filename)
        else:
            print(f"File {filename} not found")

    def load_mascon_grid(self, filename: str):
        '''
        Load mascon grid from netCDF file.

        filename: name of file containing mascon grid
        '''
        print(f"Loading mascon grid {filename}")
        with nc.Dataset(filename) as ds:
            # load variables
            self.lat, self.lon = ds['lat'][:], ds['lon'][:]
            self.latv, self.lonv = np.meshgrid(self.lat, self.lon, indexing='ij')
            self.ewh = ds['lwe_thickness'][:].data/100 # convert cm to m

            # load time in days since, convert to decimal years
            self.time = ds['time'][:].data
            try:
                ref_date = dt.datetime.strptime(ds['time'].units, 'days since %Y-%m-%dT%H:%M:%SZ')
            except:
                ref_date = dt.datetime.strptime(ds['time'].Units, 'days since %Y-%m-%dT%H:%M:%SZ')
            
            self.year, self.month, self.day = serial_date_to_YMD(ref_date, self.time)
            self.decyear = YMD_to_decimal_year(self.year, self.month, self.day)


            self.masks = {}
            try:
                self.masks['land'] = ds['land_mask'][:]
                self.masks['ocean'] = 1-self.masks['land']
            except:
                print("no mask information found for",self)




    def read_AOD1B_SH(self, filepath: str, lmax: int):
        '''
        Read monthly averaged AOD1B spherical harmonic coefficients from file.

        filepath (str): path to file containing spherical harmonic coefficients
        lmax (int): maximum degree of SH coefficients
        '''
        print(f"Loading AOD1B spherical harmonic coefficients {filepath}")
        self.aod_clm = np.zeros((self.decyear.shape[0],2,lmax+1,lmax+1))
        for iepoch, (y, m) in enumerate(zip(self.year, self.month)):
            fname = filepath.replace('YYYY', "%04i"%y).replace('MM',"%02i"%m)
            self.aod_clm[iepoch] = pysh.SHCoeffs.from_file(fname, header=True, header2=True, lmax=lmax).coeffs

    def map_to_DH(self, lmax: int = 180):
        '''
        This function maps the mascon grid to the DH grid
        for compatability with pyshtools

        Args:
        lmax (int): maximum degree determines DH grid spacing
        '''
        # construct the mapping from the mascon grid to the DH grid
        lat, lon = construct_DHgrid(lmax)
        lonv, latv = np.meshgrid(lon, lat)
        self.idx_near = get_mapping(self.lonv, self.latv, lonv, latv)
        
        # replace lon/lat with new values
        self.lon, self.lat = lon, lat
        self.lonv, self.latv = lonv, latv

        # map the mascon grid to the DH grid
        ewh_flat = self.ewh.reshape(self.ewh.shape[0],-1)
        ewh_dh = np.zeros((self.ewh.shape[0],self.idx_near.shape[0],self.idx_near.shape[1]))
        for iepoch in range(self.ewh.shape[0]):
            ewh_dh[iepoch] = ewh_flat[iepoch,self.idx_near]

        # map the masks to the DH grid
        masks_dh = {}
        for key in self.masks.keys():
            masks_dh[key] = self.masks[key].reshape(-1)[self.idx_near]
    
        # replace the attributes
        self.ewh = ewh_dh
        self.masks = masks_dh

    def DHgrid_to_SH(self, lmax: int = 180):
        '''
        Args:
        lmax (int): maximum degree of SH coefficients
        Fn (array): convert EWH to dimensionless stokes
        '''
        self.clm = np.zeros((self.ewh.shape[0], 2, lmax+1, lmax+1))
        for iepoch in range(self.ewh.shape[0]):
            self.clm[iepoch,:] = pysh.expand.SHExpandDH(self.ewh[iepoch], sampling=2, csphase=1, norm=1, lmax_calc=lmax)
    
    def SH_to_DHgrid(self, lmax: int = 180):
        '''
        Args:
        lmax (int): maximum degree of SH coefficients
        Fn (array): convert EWH to dimensionless stokes
        '''
        # construct the mapping from the mascon grid to the DH grid
        self.lat, self.lon = construct_DHgrid(lmax)
        self.lonv, self.latv = np.meshgrid(self.lon, self.lat)
        self.grid = np.zeros((self.clm.shape[0],self.lonv.shape[0],self.lonv.shape[1]))
        for iepoch in range(self.clm.shape[0]):
            self.grid[iepoch] = pysh.expand.MakeGridDH(self.clm[iepoch], sampling=2, lmax=lmax, csphase=1, norm=1)
