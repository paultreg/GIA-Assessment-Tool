"""
Classes:
    GPS_data:       class to load and manipulate GPS data
    reconstruct_dh: class to create the reconstructed timeseries

Functions:
    write_reconstruction_to_h5: write GPS data and reconstructed timeseries to h5
    read_reconstruction_h5:     read GPS data and reconstructed timeseries from h5

Author: Rebecca McGirr, 2025
Research School of Earth Sciences
The Australian National University
"""

import os
import h5py as h5
import numpy as np
import pyshtools as pysh
from .utils import linear_regression

class GPS_data:
    def __init__(self, filename=None):
        if filename is None:
            pass
        elif os.path.isfile(filename):
            if filename.endswith('.tenv3'):
                self.read_tenv3(filename)
            elif filename.endswith('.txt'):
                self.read_txt(filename)
            else:
                raise ValueError("Unknown GPS file format")
        else:
            print(f"File {filename} not found")
    
    def read_tenv3(self, filename):
        '''
        Load GPS data from tenv3 file.

        filename (str): name of file containing GPS data
        '''
        print(f"Loading GPS data {filename}")
        f = np.loadtxt(filename, skiprows=1, usecols=(2,12,20,21))
        self.decyear = f[:,0]
        self.dh = f[:,1] # in m 
        # get the latitude and longitude of the GPS station
        self.lat = np.mean(f[:,2])
        self.lon = np.mean(f[:,3])
    
    def read_txt(self, filename):
        '''
        Load GPS data from text file. Assumes the first row
        contains the latitude and longitude of the GPS station,
        columns are decimal year, height change in m.

        filename (str): name of file containing GPS data
        '''
        print(f"Loading GPS data {filename}")
        f = np.loadtxt(filename)
        self.lat, self.lon = f[0,0], f[0,1]
        self.decyear = f[1:,0]
        self.dh = f[1:,1] # in m 

    def GRACE_aligned(self, decyear, degree=2, annual=True, semiannual=True):
        '''
        Calculate the modelled value at x = decyear
        and subtract it from the data. Use to remove 
        a bias from the GPS timieseries to align with 
        the reconstructed timeseries.

        decyear (float): decimal year to calculate modelled value
        degree (int): degree of polynomial to fit
        annual (bool): include annual signal
        semiannual (bool): include semiannual signal
        '''
        # first model the GPS timeseries
        x = self.decyear - np.mean(self.decyear)
        y = self.dh
        model = linear_regression(x,y,degree=degree,annual=annual,semiannual=semiannual,verbose=False)        
        
        # now calculate the modelled value at decyear
        x = decyear - np.mean(self.decyear)
        if degree == 1:
            GPS_offset = model.a*x + model.b
        elif degree == 2:
            GPS_offset = model.a*x**2 + model.b*x + model.c
        if annual:
            GPS_offset += model.Asin*np.sin(2*np.pi*x) + model.Acos*np.cos(2*np.pi*x)
        if semiannual:
            GPS_offset += model.SAsin*np.sin(4*np.pi*x) + model.SAcos*np.cos(4*np.pi*x)
            
        #print("GPS_offset in GRACE_aligned = ",GPS_offset)
        self.dh -= GPS_offset

class reconstruct_dh:
    def __init__(self, lat, lon):
        self.lat = lat
        self.lon = lon

    def get_reconstructed_dh(self, decyear, clm_e, clm_ve):
        '''
        Reconstruct the height changes at lat, lon for each 
        epoch in decyear using the elastic and viscoelastic 
        coefficients.

        decyear (array): decimal years of the epochs
        clm_e (array): elastic coefficients
        clm_ve (array): viscoelastic coefficients
        '''
        self.decyear = decyear
        self.dh_e = np.zeros(self.decyear.shape[0])
        self.dh_ve = np.zeros(self.decyear.shape[0])
        self.dh = np.zeros(self.decyear.shape[0])

        for iepoch in range(self.decyear.shape[0]):
            self.dh_e[iepoch] = pysh.expand.MakeGridPoint(clm_e[iepoch], self.lat, self.lon)
            self.dh_ve[iepoch] = pysh.expand.MakeGridPoint(clm_ve[iepoch], self.lat, self.lon)
            self.dh[iepoch] = self.dh_e[iepoch] + self.dh_ve[iepoch]
        
        # remove the first epoch from the time series
        self.dh -= self.dh[0]
        self.dh_e -= self.dh_e[0]
        self.dh_ve -= self.dh_ve[0]

def write_reconstruction_to_h5(outfile, GPS_sites, recon):
    '''
    Write GPS site data and reconstruction to h5 file.

    outfile (str): name of file to write to
    GPS_sites (dict): dictionary of GPS site data
    recon (dict): dictionary of reconstructed data
    '''
    print(f'Writing GPS data and reconstruction to {outfile}')

    with h5.File(outfile,"w") as hf:

        # loop through GPS sites and write to h5
        for site, GPS in GPS_sites.items():
            hf.create_dataset(f'{site}/lat',data=GPS.lat)
            hf.create_dataset(f'{site}/lon',data=GPS.lon)
            hf.create_dataset(f'{site}/decyear',data=GPS.decyear)
            hf.create_dataset(f'{site}/dh',data=GPS.dh)
            hf.create_dataset(f'{site}/dh_vel',data=GPS.dh_vel)

            # loop through GIA models and write reconstructed dh,
            # dh_e, dh_ve and residual for each GPS site to h5
            for model, GIA in recon.items():
                hf.create_dataset(f'{site}/reconstruction/{model}/decyear', data=GIA[site].decyear)
                hf.create_dataset(f'{site}/reconstruction/{model}/dh', data=GIA[site].dh)
                hf.create_dataset(f'{site}/reconstruction/{model}/dh_e', data=GIA[site].dh_e)
                hf.create_dataset(f'{site}/reconstruction/{model}/dh_ve', data=GIA[site].dh_ve)
                hf.create_dataset(f'{site}/reconstruction/{model}/dh_vel', data=GIA[site].dh_vel)
                hf.create_dataset(f'{site}/reconstruction/{model}/dh_res', data=GIA[site].dh_res)
                #hf.create_dataset(f'{site}/reconstruction/{model}/model_rms', data=GIA[site].model_rms)

def read_reconstruction_h5(infile):
    '''
    Read GPS site data and reconstruction from h5 file.

    infile (str): name of file to read from

    Returns:
    GPS_sites (dict): dictionary of GPS site data
    GIA_models (list): list of GIA models
    recon (dict): dictionary of reconstructed data
    '''
    print(f'Reading GPS data and reconstruction from {infile}')
    GPS_sites = {}
    recon = {}
    with h5.File(infile, 'r') as f:
        print(f'GPS_sites: {list(f.keys())}')
        for i,site in enumerate(f.keys()):
            if i == 0:
                GIA_models = list(f[f'{site}/reconstruction'].keys())
                print(f'GIA_models: {GIA_models}')
            recon[site] = {}
            GPS_sites[site] = GPS_data()
            GPS_sites[site].lat = f[f'{site}/lat'][()]
            GPS_sites[site].lon = f[f'{site}/lon'][()]
            GPS_sites[site].decyear = f[f'{site}/decyear'][:]
            GPS_sites[site].dh = f[f'{site}/dh'][:]
            GPS_sites[site].dh_vel = f[f'{site}/dh_vel'][()]
            
            for model in f[f'{site}/reconstruction'].keys():
                recon[site][model] = reconstruct_dh(GPS_sites[site].lat, GPS_sites[site].lon)
                recon[site][model].decyear = f[f'{site}/reconstruction/{model}/decyear'][:]
                recon[site][model].dh_e = f[f'{site}/reconstruction/{model}/dh_e'][:]
                recon[site][model].dh_ve = f[f'{site}/reconstruction/{model}/dh_ve'][:]
                recon[site][model].dh = f[f'{site}/reconstruction/{model}/dh'][:]
                recon[site][model].dh_vel = f[f'{site}/reconstruction/{model}/dh_vel'][()]
                recon[site][model].dh_res = f[f'{site}/reconstruction/{model}/dh_res'][()]
                try:
                    recon[site][model].model_rms = f[f'{site}/reconstruction/{model}/model_rms'][()]
                except:
                    #print("Didn't find model_rms written into h5 file")
                    blah = 1
                    
    return GPS_sites, GIA_models, recon
