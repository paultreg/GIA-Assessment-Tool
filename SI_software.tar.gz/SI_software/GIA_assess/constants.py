"""
Constants for planet Earth.

Author: Rebecca McGirr, 2025
Research School of Earth Sciences
The Australian National University
"""

a=6.378137e6 # WGS84 Earth semi-major axis (m)
f=1.0/298.257223563 # WGS84 flattening factor
b=(1-f)*a # WGS84 Earth semi-minor axis (m)
rad_e = (2*a + b)/3 # WGS84 Earth average radius (m)
GM = 3.986004418e14 # WGS84 Earth GM w/ atmosphere (m^3/s^2)
G = 6.67430e-11 # Gravitational constant (m^3/kg/s^2)
rho_e = 5514.0 # Earth average density (kg/m^3)
rho_w = 1000.0 # Water density (kg/m^3)