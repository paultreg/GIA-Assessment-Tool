"""
Classes:
    GIA_model: class to load and manipulate GIA models

Author: Rebecca McGirr, 2025
Research School of Earth Sciences
The Australian National University
"""

import os
import numpy as np
import pyshtools as pysh
from .utils import construct_DHgrid

class GIA_model:
    def __init__(self, filename, lmax):
        if os.path.isfile(filename):
            print(f"Loading GIA model {filename}")
            self.load_gia_model(filename, lmax)
        else:
            print(f"File {filename} not found")

    def load_gia_model(self, filename, lmax):
        '''
        Load GIA model from file of dimensionless SH coefficients,
        assume that the coefficients represent an annual rate of change

        filename (str): name of file containing GIA model
        lmax (int):     maximum degree of SH coefficients
        '''
        self.rate_clm = pysh.SHCoeffs.from_file(filename, lmax=lmax).coeffs
        self.model_rms = 0.
        
    def rate_to_dGIA(self, dt):
        '''
        Convert GIA annual rate of change in dimensionless SH 
        coefficients to GIA change per epoch

        dt (array): time step in years e.g. decimal years
        '''
        self.clm = self.rate_clm[np.newaxis,:] * (dt[:,np.newaxis,np.newaxis,np.newaxis])

    def rate_SH_to_DHgrid(self, lmax):
        '''
        Convert GIA annual rate of change in dimensionless SH
        to DH grid of GIA annual rate of change.

        lmax (int): maximum degree determines DH grid spacing
        '''
        # construct the mapping from the mascon grid to the DH grid
        self.lat, self.lon = construct_DHgrid(lmax)
        self.lonv, self.latv = np.meshgrid(self.lon, self.lat)
        # multiply dimensionless stokes by conversion factor
        self.rate_grid = pysh.expand.MakeGridDH(self.rate_clm, sampling=2, lmax=lmax)

    def SH_to_DHgrid(self, lmax):
        '''
        Convert array of temporal GIA change in dimensionless SH
        to three dimensional DH grid.

        lmax (int): maximum degree determines DH grid spacing
        '''
        # construct the mapping from the mascon grid to the DH grid
        self.lat, self.lon = construct_DHgrid(lmax)
        self.lonv, self.latv = np.meshgrid(self.lon, self.lat)
        self.grid = np.zeros((self.clm.shape[0],self.lonv.shape[0],self.lonv.shape[1]))
        # multiply dimensionless stokes by conversion factor
        for iepoch in range(self.clm.shape[0]):
            self.grid[iepoch] = pysh.expand.MakeGridDH(self.clm[iepoch], sampling=2, lmax=lmax)
